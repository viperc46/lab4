<?php
/*

Name: Robyne Felton

Class: IST256.001

Assignment: Lab 4

Date Created: 11/17/19

Filename: IST256001_Lab4_FeltonRobyne.php

*/

//Database login file
$hn = "localhost";
$db = "GRADEBOOK_DB";
$un = "dba";
$pw = "dba";

?>