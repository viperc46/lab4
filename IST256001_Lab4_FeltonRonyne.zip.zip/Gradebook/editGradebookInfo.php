
<?php
/*

Name: Robyne Felton

Class: IST256.001

Assignment: Lab 4

Date Created: 11/17/19

Filename: IST256001_Lab4_FeltonRobyne.php

*/

// requires the login information for the database
require_once "GRADEBOOK_DB_login.php";

$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die("Cannot connect to database");



// THe first sql query
$query = "SELECT STUDENT.STU_CD, STUDENT.STU_F_NAME, STUDENT.STU_L_NAME FROM STUDENT";
$result_stu = $conn->query($query);
//Query error logging
if(!$result_stu) die("Query was unable to run ");
//grabs the number of rows
$rows = $result_stu->num_rows;
$option_stu = " ";

//for loop to get the rows that places the names in a drop down box
for($x = 0; $x < $rows; ++$x) {
    $row = $result_stu->fetch_array(MYSQLI_ASSOC);
    $option_stu .= '<option value = "' . $row['STU_CD'] . '">' . $row['STU_F_NAME'] . " " . $row['STU_L_NAME']. '</option>';
}

// second sql query
$query = "SELECT CLASS.CLS_ID, COURSE.CRS_CD, COURSE.CRS_TITLE, CLASS.CLS_SECTION, CLASS.SEM_CD, SEMESTER.SEM_TERM, SEMESTER.SEM_YEAR
			FROM CLASS, COURSE, SEMESTER
			WHERE CLASS.CRS_CD = COURSE.CRS_CD AND CLASS.SEM_CD = SEMESTER.SEM_CD";
$result_cls = $conn->query($query);
//query error logging
if(!$result_cls) die ("Could not run query");
$option_cls = "";

//for loop that places the course values into a drop down box
for ($x = 0; $x < $rows; ++$x) {
    $row = $result_cls->fetch_array(MYSQLI_ASSOC);
    $option_cls .= '<option value = "' . $row['CLS_ID'] . ' ">' . $row['CRS_TITLE'] . ", " . $row['CLS_SECTION'] . ", " . $row['SEM_TERM'] . ", " . $row['SEM_YEAR'] . '</option>';
}

//Starts the roster information
$roster_id = 0;
$rst_query = "SELECT MAX(RST_ID) FROM ROSTER";

$db_upd = "Please enter new record data:";

//if statement to check to see if the file is submitted before running the query and
if(isset($_POST["RST_GRD"])) {
    $rst_id_query = $conn->query($rst_query);
    if(!$rst_id_query) die("Could not run query");

    $rowval = $rst_id_query->fetch_row();
    $roster_id = $rowval[0];
    $roster_id++;
    $student = $_POST["STU_CODE"];
    $class = $_POST["CLS_ID"];
    $grade = $_POST["RST_GRD"];
    $query = "INSERT INTO ROSTER VALUES('$roster_id', '$student', '$class', '$grade')";
    //Inserts the method
    $result_prod = $conn->query($query);
    //Query error handling
    if(!$result_prod) die("This query does't run or update");
    //confirms that the the roster has been updated
    echo "New Record added to Roster!  <br>";
    echo "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~<br>";

}
// html form that will display the dropdown and take in text
echo <<<_END
	<html>
		<head>
			<title>Gradebook Input Form</title>
		</head>
		<body>
			$db_upd
			<br>
			<br>
			<form method="post" action="editGradebookInfo.php">
			Select Student:
			<select name="STU_CODE" size="1">
				$option_stu
			</select>
			<br>
				Select Class:
				<select name="CLS_ID" size="1">
					$option_cls
				</select>
				<br>
				Enter Grade:
				<input name="RST_GRD" type="text" max=50>
				<br>

				<input type="Submit">
				<br>
			</form>
		</body>
	</html>
_END;

?>