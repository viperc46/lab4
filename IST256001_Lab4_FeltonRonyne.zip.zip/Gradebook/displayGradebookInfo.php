<?php
/*

Name: Robyne Felton

Class: IST256.001

Assignment: Lab 4

Date Created: 11/17/19

Filename: IST256001_Lab4_FeltonRobyne.php

*/
//require the login file
require_once "GRADEBOOK_DB_login.php";

//check connection
$conn = new mysqli($hn, $un, $pw, $db);
if($conn->connect_error) die("Cannot connect to database");
//main query to pull in all of the information that is needed
$query = "SELECT STUDENT.STU_F_NAME, STUDENT.STU_L_NAME, COURSE.CRS_CD, COURSE.CRS_TITLE, CLASS.CLS_SECTION, SEMESTER.SEM_TERM, SEMESTER.SEM_YEAR, ROSTER.RST_LTR_GRADE FROM CLASS, COURSE, ROSTER, SEMESTER, STUDENT WHERE CLASS.CRS_CD = COURSE.CRS_CD AND CLASS.SEM_CD = SEMESTER.SEM_CD AND ROSTER.CLS_ID = CLASS.CLS_ID AND ROSTER.STU_CD = STUDENT.STU_CD ";
$result_gb = $conn->query($query);
//query error handling
if(!$result_gb) die ("Cant connect to this one");

$rows = $result_gb->num_rows;
$dis_gb = " ";

//gathers the information from the sql file and outputs them in a clear and formatted way
for($x = 0; $x < $rows; ++$x) {
    $row = $result_gb->fetch_array(MYSQLI_ASSOC);
    $dis_gb .= '<div><label>STUDENT:</label><label class="dataItem">' . $row['STU_F_NAME'] . " " . $row['STU_L_NAME']. '</label></div><br>';
    $dis_gb .= '<div><label>CLASS:</label><label class="dataItem">' . $row['CRS_CD'] . "(" . $row['CRS_TITLE'].") ".'</label><label>SECTION:</label><label class="dataItem">' . $row['CLS_SECTION']. '</label></div><br>';
    $dis_gb .= '<div><label>SEMESTER:</label><label class="dataItem">' . $row['SEM_TERM'] . " " . $row['SEM_YEAR']. '</label></div><br>';
    //if statement that if there isnt a grade it puts in 2 dashes
    if( $row['RST_LTR_GRADE'] != NULL)
        $dis_gb .= '<div><label>GRADE:</label><label class="dataItem">' . $row['RST_LTR_GRADE'] .'</label></div><br><br>';
    else
        $dis_gb .= '<div><label>GRADE:</label><label class="dataItem">' . "--" .'</label></div><br><br>';
}
//displays the grades in the sheet
echo "<div><br>$dis_gb</div>";


?>