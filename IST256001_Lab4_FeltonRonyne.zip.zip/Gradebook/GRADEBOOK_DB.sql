-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 18, 2019 at 08:19 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `GRADEBOOK_DB`
--

-- --------------------------------------------------------

--
-- Table structure for table `CLASS`
--

CREATE TABLE `CLASS` (
  `CLS_ID` int(10) NOT NULL,
  `CRS_CD` varchar(10) NOT NULL,
  `CLS_SECTION` int(3) NOT NULL,
  `SEM_CD` varchar(10) NOT NULL,
  `CLS_SCHEDULE` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `CLASS`
--

INSERT INTO `CLASS` (`CLS_ID`, `CRS_CD`, `CLS_SECTION`, `SEM_CD`, `CLS_SCHEDULE`) VALUES
(123, 'MIS204', 1, 'FA19', 'MW 2:30-3:45'),
(234, 'MIS204', 2, 'FA19', 'M 6:00-9:00'),
(345, 'IST256', 1, 'FA19', 'MW 4:00-5:15'),
(456, 'IST140', 2, 'FA19', 'W 6:00-9:00'),
(567, 'IST413', 1, 'SP20', 'MW 11:15:12:30'),
(678, 'MIS204', 1, 'SP20', 'MW 4:00-5:15'),
(789, 'IST210', 1, 'SP20', 'TR 3:05-4:20'),
(890, 'IST411', 1, 'SP20', 'W 6:00-9:00');

-- --------------------------------------------------------

--
-- Table structure for table `COURSE`
--

CREATE TABLE `COURSE` (
  `CRS_CD` varchar(10) NOT NULL,
  `CRS_TITLE` varchar(50) NOT NULL,
  `CRS_DESC` varchar(500) DEFAULT NULL,
  `CRS_CREDITS` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `COURSE`
--

INSERT INTO `COURSE` (`CRS_CD`, `CRS_TITLE`, `CRS_DESC`, `CRS_CREDITS`) VALUES
('IST140', 'Introduction to Application Development', 'Learn the concepts and skills for application development', 3),
('IST210', 'Organization of Data', 'Learn the concepts of databases including the storage, manipulation, evaluation, and display of data and related issues', 3),
('IST256', 'Programming for the Web', 'Learn the knowledge and skills to create both basic and more dynamic web-based content pages and applications', 3),
('IST411', 'Distributed-Object Computing', 'Learn the concepts of distributed-object computing, including client/server computing which is an important platform for real-world computing systems', 3),
('IST413', 'Usability Engineering', 'Learn the concepts of usability, requirements gathering and analysis, activity design, information design, interaction design, documentation design, user testing and usability evaluation ', 3),
('MIS204', 'Introduction to Business Information Systems', 'Introduction to the use of information systems in business organizations', 3);

-- --------------------------------------------------------

--
-- Table structure for table `ROSTER`
--

CREATE TABLE `ROSTER` (
  `RST_ID` int(10) NOT NULL,
  `STU_CD` varchar(10) NOT NULL,
  `CLS_ID` int(10) NOT NULL,
  `RST_LTR_GRADE` varchar(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ROSTER`
--

INSERT INTO `ROSTER` (`RST_ID`, `STU_CD`, `CLS_ID`, `RST_LTR_GRADE`) VALUES
(135, 'AM4004', 345, 'A'),
(197, 'AM4004', 123, ''),
(357, 'DW5005', 345, 'C'),
(531, 'JH2002', 123, ''),
(579, 'JH2002', 345, 'C'),
(753, 'PB3003', 345, 'B'),
(975, 'DW5005', 123, ''),
(976, 'HF8008', 345, 'D'),
(977, 'HF8008', 345, 'D'),
(978, 'HF8008', 345, 'D'),
(979, 'OM7007', 456, 'B'),
(980, 'OM7007', 456, 'B'),
(981, 'OM7007', 456, 'B'),
(982, 'OM7007', 456, 'B'),
(983, 'OM7007', 456, 'B'),
(984, 'OM7007', 456, 'B'),
(985, 'OM7007', 456, 'B'),
(986, 'AB8008', 890, 'A'),
(987, 'AM4004', 123, 'A');

-- --------------------------------------------------------

--
-- Table structure for table `SEMESTER`
--

CREATE TABLE `SEMESTER` (
  `SEM_CD` varchar(10) NOT NULL,
  `SEM_TERM` varchar(10) NOT NULL,
  `SEM_YEAR` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `SEMESTER`
--

INSERT INTO `SEMESTER` (`SEM_CD`, `SEM_TERM`, `SEM_YEAR`) VALUES
('FA19', 'Fall', 2019),
('FA20', 'Fall', 2020),
('FA21', 'Fall', 2021),
('SP20', 'Spring', 2020),
('SP21', 'Spring', 2021);

-- --------------------------------------------------------

--
-- Table structure for table `STUDENT`
--

CREATE TABLE `STUDENT` (
  `STU_CD` varchar(10) NOT NULL,
  `STU_F_NAME` varchar(30) NOT NULL,
  `STU_L_NAME` varchar(30) NOT NULL,
  `STU_EMAIL` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `STUDENT`
--

INSERT INTO `STUDENT` (`STU_CD`, `STU_F_NAME`, `STU_L_NAME`, `STU_EMAIL`) VALUES
('AB8008', 'Andrew', 'Bernard', 'AM8008@PSU.EDU'),
('AM4004', 'Angela', 'Martin', 'AM4004@PSU.EDU'),
('CB3003', 'Creed', 'Bratton', 'CB3003@PSU.EDU'),
('DP9009', 'Darryl', 'Philbin', 'DP9009@PSU.EDU'),
('DW5005', 'Dwight', 'Schrute', 'DW5005@PSU.EDU'),
('EH5005', 'Erin', 'Hannon', 'EH5005@PSU.EDU'),
('HF8008', 'Holly', 'Flax', 'HF8008@PSU.EDU'),
('JH2002', 'James', 'Halpert', 'JH2002@PSU.EDU'),
('KK7007', 'Kelly', 'Kapoor', 'KK7007@PSU.EDU'),
('KM6006', 'Kevin', 'Malone', 'KM6006@PSU.EDU'),
('MP2002', 'Meredith', 'Palmer', 'MP2002@PSU.EDU'),
('MS1001', 'Michael', 'Scott', 'MS1001@PSU.EDU'),
('OM7007', 'Oscar', 'Martinez', 'OM7007@PSU.EDU'),
('PB3003', 'Pamela', 'Beasley', 'PM3003@PSU.EDU'),
('PV9009', 'Phyllis', 'Vance', 'PH9009@PSU.EDU'),
('RH6006', 'Ryan', 'Howard', 'RH6006@PSU.EDU'),
('SH1001', 'Stanley', 'Hudson', 'SH1001@PSU.EDU'),
('TF4004', 'Toby', 'Flenderson', 'TF4004@PSU.EDU');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `CLASS`
--
ALTER TABLE `CLASS`
  ADD PRIMARY KEY (`CLS_ID`),
  ADD KEY `FK_to_COURSE` (`CRS_CD`),
  ADD KEY `FK_to_SEMESTER` (`SEM_CD`);

--
-- Indexes for table `COURSE`
--
ALTER TABLE `COURSE`
  ADD PRIMARY KEY (`CRS_CD`);

--
-- Indexes for table `ROSTER`
--
ALTER TABLE `ROSTER`
  ADD PRIMARY KEY (`RST_ID`),
  ADD KEY `FK_to_CLASS` (`CLS_ID`),
  ADD KEY `FK_to_STUDENT` (`STU_CD`);

--
-- Indexes for table `SEMESTER`
--
ALTER TABLE `SEMESTER`
  ADD PRIMARY KEY (`SEM_CD`);

--
-- Indexes for table `STUDENT`
--
ALTER TABLE `STUDENT`
  ADD PRIMARY KEY (`STU_CD`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `CLASS`
--
ALTER TABLE `CLASS`
  ADD CONSTRAINT `FK_to_COURSE` FOREIGN KEY (`CRS_CD`) REFERENCES `COURSE` (`CRS_CD`),
  ADD CONSTRAINT `FK_to_SEMESTER` FOREIGN KEY (`SEM_CD`) REFERENCES `SEMESTER` (`SEM_CD`);

--
-- Constraints for table `ROSTER`
--
ALTER TABLE `ROSTER`
  ADD CONSTRAINT `FK_to_CLASS` FOREIGN KEY (`CLS_ID`) REFERENCES `CLASS` (`CLS_ID`),
  ADD CONSTRAINT `FK_to_STUDENT` FOREIGN KEY (`STU_CD`) REFERENCES `STUDENT` (`STU_CD`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
